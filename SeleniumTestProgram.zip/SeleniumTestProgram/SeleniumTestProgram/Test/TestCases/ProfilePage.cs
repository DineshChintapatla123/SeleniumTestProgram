﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumTestProgram.Test.TestCases
{

    class ProfilePage
    {

        public IWebElement webSelectdropdwn => PropertyCollection.driver.FindElement(By.Id("TitleId"));

        public IWebElement webIntial => PropertyCollection.driver.FindElement(By.Id("Initial"));

        public IWebElement webFirstName => PropertyCollection.driver.FindElement(By.Id("FirstName"));

        public IWebElement webMiddleName => PropertyCollection.driver.FindElement(By.Id("MiddleName"));

        public IWebElement webSaveButton => PropertyCollection.driver.FindElement(By.Name("Save"));

    }
}
