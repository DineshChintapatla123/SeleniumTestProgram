﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.UI;

namespace SeleniumTestProgram
{
    class SeleniumGetMethods
    {
        public static string GetText(string element,PropertType elementtype)
        {
            if (elementtype == PropertType.Id)
                return PropertyCollection.driver.FindElement(By.Id(element)).GetAttribute("value");
            else if (elementtype ==PropertType.Name)
                return PropertyCollection.driver.FindElement(By.Name(element)).GetAttribute("value"); 
            else return String.Empty;
        }

        public static string GetDDL(string element,PropertType elementtype)
        {
            if (elementtype == PropertType.Id)
                return new SelectElement(PropertyCollection.driver.FindElement(By.Id(element))).AllSelectedOptions.SingleOrDefault().Text;
            else if (elementtype == PropertType.Name)
                return new SelectElement(PropertyCollection.driver.FindElement(By.Id(element))).AllSelectedOptions.SingleOrDefault().Text;
            else
                return String.Empty;
        }

    }
}
