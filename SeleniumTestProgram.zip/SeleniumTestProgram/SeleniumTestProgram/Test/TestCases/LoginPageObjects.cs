﻿using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumTestProgram
{
   
    class LoginPageObjects
    {
        IWebDriver _driver;


         public LoginPageObjects() => this._driver = PropertyCollection.driver;


        public IWebElement webUserName => _driver.FindElement(By.Name("UserName"));
        

        public IWebElement webPassWord => _driver.FindElement(By.Name("Password"));

        public IWebElement webLogin => _driver.FindElement(By.Name("Login"));

        
      
    }
}
