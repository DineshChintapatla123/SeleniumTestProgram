﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using SeleniumTestProgram.Test.TestCases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumTestProgram
{
    class FirstProgram
    {


  
        static void Main(string[] args)
        {

        }

        [SetUp]
        public void Intialize()
        {
            PropertyCollection.driver = new ChromeDriver();

            // Navigating to the google website
            PropertyCollection.driver.Navigate().GoToUrl("http://executeautomation.com/demosite/Login.html");
            Console.WriteLine("navigating to the URL");
            PropertyCollection.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

        }


        [Test]
        public void TestExecution()
        {
            //Login



            LoginPageObjects page = new LoginPageObjects();
            page.webUserName.SendKeys("Dinesh");
            page.webPassWord.SendKeys("*****");
            page.webLogin.Click();

            // Profile page

            ProfilePage profile = new ProfilePage();
            profile.webIntial.Click();
            profile.webIntial.Click();

            







            //SeleniumSetMethods.EnterText("UserName", "Dinesh", PropertType.Name);

            //SeleniumSetMethods.EnterText("Password", "*****", PropertType.Name);
            //SeleniumSetMethods.MethodClick("Login", PropertType.Name);
            //driver.FindElement(By.Name("Login")).Click();
            //PropertyCollection.driver.FindElement(By.XPath("//form/p/input[@name='Login']")).Click();
            //SeleniumSetMethods.SelectDropdown("TitleId", "Mr.",PropertType.Id);
            //SeleniumSetMethods.EnterText("Initial", "Dinesh", PropertType.Name);
            //SeleniumSetMethods.MethodClick("Save", PropertType.Name);
            string initialname=SeleniumGetMethods.GetText("Initial", PropertType.Name);
            Console.WriteLine("the value of the initial " + initialname);

            string Title = SeleniumGetMethods.GetDDL( "TitleId", PropertType.Id);

            Console.WriteLine("the value of the Title " + Title);
            //SeleniumSetMethods.MethodClick(driver, "HtmlPopup", "href");


        }
        [TearDown]
        public void ClosingBrwser()
        {

            PropertyCollection.driver.Close();
            Console.WriteLine("closing the browser");

        }
    }
}
