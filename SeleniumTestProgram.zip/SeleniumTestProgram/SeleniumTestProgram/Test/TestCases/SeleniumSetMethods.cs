﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.UI;

namespace SeleniumTestProgram
{
    class SeleniumSetMethods
    {


        public static void EnterText( string element, string value,PropertType elementtype)
        {
            if (elementtype == PropertType.Id)
                PropertyCollection.driver.FindElement(By.Id(element)).SendKeys(value);
            else if (elementtype == PropertType.Name)
                PropertyCollection.driver.FindElement(By.Name(element)).SendKeys(value);
        }


        public static void MethodClick( string element, PropertType elementtype)
        {
            if (elementtype == PropertType.Id)
            {
                PropertyCollection.driver.FindElement(By.Id(element)).Click();
                Console.WriteLine("Click happend by Id");
            }
            else if (elementtype == PropertType.Name)
            {
                PropertyCollection.driver.FindElement(By.Name(element)).Click();
                Console.WriteLine("Click happend by name");
            }
            else if (elementtype == PropertType.PartialLinkText)
            {
                PropertyCollection.driver.FindElement(By.PartialLinkText(element)).Click();
                Console.WriteLine("Click happend by href");
            }
        }

        public static void SelectDropdown(string element, string value,PropertType elementtype)
        {

            if (elementtype == PropertType.Id)
                new SelectElement(PropertyCollection.driver.FindElement(By.Id(element))).SelectByText(value);
            else if (elementtype == PropertType.Name)
                new SelectElement(PropertyCollection.driver.FindElement(By.Name(element))).SelectByText(value);
        }
    }
}
