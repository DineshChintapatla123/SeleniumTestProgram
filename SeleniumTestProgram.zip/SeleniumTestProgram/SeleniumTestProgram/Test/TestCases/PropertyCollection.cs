﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumTestProgram
{

    enum PropertType
    {
        Id,
        Name,
        LinkText,
        PartialLinkText,
        ClassName    

    }
    
    class PropertyCollection
    {
        public static IWebDriver driver{ get; set; }

    }
}
