package com.blocket.workflows;

import org.testng.annotations.BeforeMethod;

import com.blocket.commonmethods.UserActions;
import com.blocket.pageobjects.HomeScreen;

public class BaseTest {
	
	@BeforeMethod
	public void navigateToPage() throws InterruptedException {
		UserActions actions = new UserActions();
		HomeScreen homescreen = actions.NavigatetoHomescreen();
		homescreen.allowcookies();
		
		
	}

}
