package com.blocket.workflows;

import com.blocket.pageobjects.WelcomePage;


public class CityCheck 
{
	
	WelcomePage welcomepage = new WelcomePage();
	
	public void SelectCity()
	{
		welcomepage.SelectCity("Stockholm");
	}
	
	
	
	



}
