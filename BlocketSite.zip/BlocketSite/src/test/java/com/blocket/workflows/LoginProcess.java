package com.blocket.workflows;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.blocket.commonmethods.UserActions;
import com.blocket.pageobjects.LoginPage;
import com.blocket.pageobjects.WelcomePage;



public class LoginProcess extends BaseTest {


	LoginPage loginpage = new LoginPage();
	UserActions useractions = new UserActions();
	WelcomePage welcomepage = new WelcomePage();

	// Login using user name and password
	@Test
	public void login() {
		welcomepage.goToLoginPage();
		loginpage.login("uitestinguser@gmail.com", "sogeti123");
		Assert.assertTrue(loginpage.isLoggedIn());
	}

	

}
