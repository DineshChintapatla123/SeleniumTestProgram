package com.blocket.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WelcomePage
{
	@FindBy(tagName = "Sign in")
	private WebElement webSignInLink;
	
	@FindBy(tagName = "Stockholm")
	private WebElement webCityName;
	
	@FindBy(tagName = "Skåne")
	private WebElement webCityName1;
	
	@FindBy(tagName = "Whole Sweden")
	private WebElement webCityName2;
	
	@FindBy(linkText= " Malmö ")
	private WebElement webinnercity;
	

	public void goToLoginPage() {
		webSignInLink.click();
	}
	
	public void SelectCity(String city) 
	{
		if (city == webCityName.getText() )
			webCityName.click();
		else if (city == webCityName1.getText() )
			webCityName1.click();
		else if (city == webCityName2.getText() )
			webCityName2.click();		
		
	}
	
	
	
	
	
	
	
	
	

}
