package com.blocket.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
	
	@FindBy(id = "CredIdentifier")
	private WebElement userNameField;
	
	@FindBy(id = "CredPassword")
	private WebElement passWordField;
	
	@FindBy(className = "btn btn-primary")
	private WebElement signInButton;
	
	@FindBy(linkText ="log_out_clicked")
	private WebElement logoutlink;
	
	
		public void login(String username, String password) {
			userNameField.sendKeys(username);
			passWordField.sendKeys(password);
			signInButton.click();
		}

		public boolean isLoggedIn()
		{
			// check if log out button is on page
			if (logoutlink.isEnabled())	
			return true;
			else 
			return false;
			
		}
}
