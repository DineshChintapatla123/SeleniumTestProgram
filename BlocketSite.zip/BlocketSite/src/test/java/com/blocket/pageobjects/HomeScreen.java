package com.blocket.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomeScreen
{
	@FindBy(id="searcharea_simple")
	private WebElement searchDropdown;
	
	@FindBy(xpath="//*[@class='Buttonstyles__ChildrenWrapper-hz08m4-3 INVPu'])[2] ")
	private WebElement popup;
	
	
	public Boolean CheckCityName(String city)
	{
		if(city==searchDropdown.getText())
			return true;
			else
			return false;
	}


	public void allowcookies() {
		// TODO Auto-generated method stub
		if (popup.isDisplayed())
			popup.click();
		
	}
	
}
