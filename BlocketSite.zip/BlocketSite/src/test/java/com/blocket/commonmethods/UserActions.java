package com.blocket.commonmethods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.blocket.pageobjects.HomeScreen;



public class UserActions {

	public HomeScreen NavigatetoHomescreen () throws InterruptedException 
	{
		
		System.setProperty("webdriver.chrome.driver","src/test/resources/chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("https://www.blocket.se/");
		return new HomeScreen();
	}

}
